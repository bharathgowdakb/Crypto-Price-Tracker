import { useState, useEffect } from "react";
import axios from "axios";
import { Line } from "react-chartjs-2";
import "tailwindcss/tailwind.css";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

const CryptoTracker = () => {
  const [coins, setCoins] = useState([]);
  const [search, setSearch] = useState("");
  const [chartData, setChartData] = useState(null);
  const [selectedCoin, setSelectedCoin] = useState("bitcoin");

  useEffect(() => {
    fetchCoins();
    fetchChartData(selectedCoin);
  }, [selectedCoin]);

  const fetchCoins = async () => {
    try {
      const { data } = await axios.get(
        "https://api.coingecko.com/api/v3/coins/markets",
        {
          params: {
            vs_currency: "usd",
            order: "market_cap_desc",
            per_page: 10,
            page: 1,
            sparkline: false,
          },
        }
      );
      setCoins(data);
    } catch (error) {
      console.error("Error fetching coins:", error);
    }
  };

  const fetchChartData = async (coin) => {
    try {
      const { data } = await axios.get(
        `https://api.coingecko.com/api/v3/coins/${coin}/market_chart`,
        {
          params: { vs_currency: "usd", days: 7 },
        }
      );
      setChartData({
        labels: data.prices.map((price) =>
          new Date(price[0]).toLocaleDateString()
        ),
        datasets: [
          {
            label: `${coin.toUpperCase()} Price (USD)`,
            data: data.prices.map((price) => price[1]),
            borderColor: "#4A90E2",
            backgroundColor: "rgba(74,144,226,0.2)",
            borderWidth: 2,
          },
        ],
      });
    } catch (error) {
      console.error("Error fetching chart data:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Crypto Price Tracker</h1>
      <input
        type="text"
        placeholder="Search cryptocurrency..."
        className="w-full p-2 mb-4 rounded bg-gray-800 text-white"
        onChange={(e) => setSearch(e.target.value)}
      />
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-800">
              <th className="p-2">Logo</th>
              <th className="p-2">Name</th>
              <th className="p-2">Price</th>
              <th className="p-2">Market Cap</th>
            </tr>
          </thead>
          <tbody>
            {coins
              .filter((coin) =>
                coin.name.toLowerCase().includes(search.toLowerCase())
              )
              .map((coin) => (
                <tr
                  key={coin.id}
                  className="border-b border-gray-700 hover:bg-gray-800 cursor-pointer"
                  onClick={() => setSelectedCoin(coin.id)}
                >
                  <td className="p-2">
                    <img src={coin.image} alt={coin.name} className="w-6 h-6" />
                  </td>
                  <td className="p-2">{coin.name}</td>
                  <td className="p-2">${coin.current_price.toFixed(2)}</td>
                  <td className="p-2">${coin.market_cap.toLocaleString()}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      {chartData && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold mb-2">
            {selectedCoin.toUpperCase()} - 7 Day Price Chart
          </h2>
          <Line data={chartData} />
        </div>
      )}
    </div>
  );
};

export default CryptoTracker;
